#include "../ejs.h"
#include <string.h>

// Función principal: publicar un tuit
tuit_t *publicar(char *mensaje, usuario_t *user) {

  tuit_t* tuit = malloc(sizeof(tuit_t));
  strcpy(tuit->mensaje, mensaje);
  tuit->id_autor = user->id;
  tuit->retuits = 0;
  tuit->favoritos = 0;

  publicar_en_feed(tuit, user->feed);

  for (uint32_t i = 0; i < user->cantSeguidores; i++) {
    feed_t* feed = user->seguidores[i]->feed;
    publicar_en_feed(tuit, feed);
  }

  return tuit;
}

void publicar_en_feed(tuit_t* tuit, feed_t* feed) {
  publicacion_t* publicacion = malloc(sizeof(publicacion_t));
  publicacion->value = tuit;
  publicacion->next = feed->first;
  feed->first = publicacion;
}