#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define WITH_ABI_MESSAGE
#include "../../test_utils/test-utils.h"
#include "../ejs.h"

int main(int argc, char* argv[]) {
   
}
