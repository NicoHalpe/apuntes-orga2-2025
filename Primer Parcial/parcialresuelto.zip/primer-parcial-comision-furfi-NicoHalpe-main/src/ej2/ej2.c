#include "../ejs.h"

void borrarTuitsDeUsuario(usuario_t* usuario, feed_t* feed) {
  publicacion_t* publicacion = feed->first;
  publicacion_t* anterior = NULL;

  while (publicacion)
  {
    publicacion_t* next = publicacion->next;
    
    if (publicacion->value->id_autor == usuario->id) {
        if(anterior) {
          anterior->next = next;
        } else {
          feed->first = next;
        }
        free(publicacion);
    } else {
      anterior = publicacion;
    }
    publicacion = next;
  }
}

void bloquearUsuario(usuario_t *usuario, usuario_t *usuarioABloquear){

  usuario->bloqueados[usuario->cantBloqueados] = usuarioABloquear;
  usuario->cantBloqueados++;
  borrarTuitsDeUsuario(usuario, usuarioABloquear->feed);
  borrarTuitsDeUsuario(usuarioABloquear, usuario->feed);

  return;
}
