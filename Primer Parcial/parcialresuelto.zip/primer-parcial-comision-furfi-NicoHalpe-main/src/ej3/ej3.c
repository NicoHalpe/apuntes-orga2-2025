#include "../ejs.h"

int contarTuitsSobresalientes(usuario_t* user, 
                        uint8_t (*esTuitSobresaliente)(tuit_t *)) {

    int res = 0;
    feed_t* feed = user->feed;

    publicacion_t* publicacion = feed->first;

    while (publicacion)
    {
        if(publicacion->value->id_autor != user->id) {
            publicacion = publicacion->next;
            continue;
        }
        if(esTuitSobresaliente(publicacion->value)) res++;
        publicacion = publicacion->next;
    }

    return res;
}

tuit_t **trendingTopic(usuario_t *user,
                       uint8_t (*esTuitSobresaliente)(tuit_t *)) {

    int cant = contarTuitsSobresalientes(user, esTuitSobresaliente);

    if(cant == 0) return NULL;

    cant++;
    
    tuit_t** res = malloc(cant * 8);
    res[cant-1] = NULL;

    publicacion_t* publicacion = user->feed->first;

    int contador = 0;

    while (publicacion)
    {
        if(publicacion->value->id_autor != user->id) {
            publicacion = publicacion->next;
            continue;
        }
        if(esTuitSobresaliente(publicacion->value)) {
            res[contador] = publicacion->value;
            contador++;
        }
        publicacion = publicacion->next;
    }

    return res;
}

